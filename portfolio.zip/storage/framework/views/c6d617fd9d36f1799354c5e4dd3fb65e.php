<h2>Nuevo mensaje de contacto</h2>
<p><strong>Nombre:</strong> <?php echo e($data['name']); ?></p>
<p><strong>Empresa:</strong> <?php echo e($data['company'] ?? '—'); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Teléfono:</strong> <?php echo e($data['phone'] ?? '—'); ?></p>
<p><strong>Mensaje:</strong></p>
<p><?php echo e($data['message']); ?></p><?php /**PATH C:\Proyectos\portfolio\resources\views/emails/contact.blade.php ENDPATH**/ ?>