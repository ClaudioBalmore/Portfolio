<template>
    <section id="proyectos" class="bg-background-light w-full p-4">
        <div class="max-w-3xl mx-auto py-8">
            <div class="flex gap-2 justify-left items-center align-center">
                <div class="w-2.5 h-px bg-gray"></div>
                <h2 class="text-xs font-primary text-gray tracking-[0.2em]">Proyectos</h2>
            </div>

            <p class="text-3xl font-primary pt-4 max-w-80">
                Mis proyectos más destacados.
            </p>
            <div class="flex flex-wrap gap-5 justify-center pt-6">
                <project-card></project-card>
            </div>
        </div>
           
    </section>
</template>